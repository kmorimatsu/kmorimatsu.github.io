# kmz80web
# fzkmweb
KM-Z80 web

## about KM-Z80 web
KM-Z80 web is an emulator of Sharp MZ-80K compatible personal computer.

## License
LGPL 2.1 except for rom.js, that is provided under another license. See the license of "MZ-NEW MONITOR".
